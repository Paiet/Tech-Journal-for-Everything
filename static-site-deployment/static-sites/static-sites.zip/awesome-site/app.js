var button = document.querySelector('#clicky');

button.addEventListener('click', function(e){
	window.alert('You have clicked the button');
});
